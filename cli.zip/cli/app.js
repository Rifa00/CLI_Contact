const fun = require("./fun");
const yargs = require("yargs");

// menambahkan contact
yargs
  .command({
    command: "add",
    describe: "Menambahkan contact baru :",
    builder: {
      name: {
        describe: "nama lengkap",
        demandOption: true,
        type: "string",
      },
      email: {
        describe: "email",
        demandOption: true,
        type: "string",
      },

      no: {
        describe: "no Hp",
        demandOption: false,
        type: "string",
      },
      desc: {
        describe: "description",
        demandOption: false,
        type: "string",
      },
    },
    handler(argv) {
      fun.addContact(argv.name, argv.email, argv.no, argv.desc);
    },
  })
  .demandCommand();

// menampilkan list contact

yargs.command({
  command: "list",
  describe: "Menampilakan list contact :",
  handler() {
    fun.listContact();
  },
});

// menmpilkan detail contact

yargs.command({
  command: "src",
  describe: "Menampilakan detail contact sesuai nama:",
  builder: {
    name: {
      describe: "nama lengkap",
      demandOption: true,
      type: "string",
    },
  },

  handler(argv) {
    fun.searchContact(argv.name);
  },
});

yargs.command({
  command: "dtl",
  describe: "Menampilakan detail contact sesuai email:",
  builder: {
    email: {
      describe: "email",
      demandOption: true,
      type: "string",
    },
  },

  handler(argv) {
    fun.detailContact(argv.email);
  },
});
yargs.command({
  command: "up",
  describe: "Update contact sesuai email:",
  builder: {
    email: {
      describe: "email",
      demandOption: true,
      type: "string",
    },
    newName: {
      describe: "newName",
      demandOption: false,
      type: "string",
    },
    newEmail: {
      describe: "newEmail",
      demandOption: false,
      type: "string",
    },
    newDesc: {
      describe: "newDesc",
      demandOption: false,
      type: "string",
    },
    newNo: {
      describe: "newNo",
      demandOption: false,
      type: "string",
    },
  },

  handler(argv) {
    fun.updateContact(
      argv.email,
      argv.newName,
      argv.newEmail,
      argv.newDesc,
      argv.newNo
    );
  },
});

// menghapus contact

yargs.command({
  command: "dlt",
  describe: "Menghapus contact sesuai email:",
  builder: {
    email: {
      describe: "email",
      demandOption: true,
      type: "string",
    },
  },

  handler(argv) {
    fun.deleteContact(argv.email);
  },
});
yargs.parse();
