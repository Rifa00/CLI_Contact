const validator = require("validator");
const chalk = require("chalk");
const fs = require("fs");

// bikin folder jika belum ada

const dirPath = "./data";
if (!fs.existsSync(dirPath)) {
  fs.mkdirSync(dirPath);
}

// bikin file jika belum ada

const path = "./data/contact.json";

if (!fs.existsSync(path)) {
  fs.writeFileSync(path, "[]", "utf-8");
}

const loadcont = () => {
  const buffer = fs.readFileSync("data/contact.json", "utf-8");
  const contacts = JSON.parse(buffer);
  return contacts;
};

const addContact = (name, email, no, desc) => {
  const contact = { name, email, no, desc };

  const contacts = loadcont();

  const duplikat = contacts.find((contact) => contact.email === email);
  if (duplikat) {
    console.log(chalk.red.inverse.bold("Email ini sudah terdaftar!"));
    return false;
  }
  if (!validator.isEmail(email)) {
    console.log(chalk.red.inverse.bold(`Email: "${email}", tidak valid!`));
    return false;
  }

  if (no) {
    if (!validator.isMobilePhone(no, "id-ID")) {
      console.log(chalk.red.inverse.bold(`Nomor: "${no}", tidak valid!`));
      return false;
    }
  }
  contacts.push(contact);

  fs.writeFileSync("data/contact.json", JSON.stringify(contacts));
  console.log(chalk.green.inverse.bold(`"${name}" berhasil dimasukan!`));
};

const listContact = () => {
  const contacts = loadcont();

  if (contacts.length === 0) {
    console.log(chalk.yellow.inverse.bold("Data tidak ditemukan! "));
  } else {
    console.log(chalk.grey.inverse.bold(" Daftar contact : "));
    contacts.forEach((contact, i) => {
      console.log(`${i + 1}. ${contact.name} - ${contact.email}`);
    });
  }
};
// search Contact

const searchContact = (name) => {
  const contacts = loadcont();
  const contact = contacts.filter(
    (contact) => contact.name.toLowerCase() === name.toLowerCase()
  );
  if (contact == false) {
    console.log(chalk.red.inverse.bold(`"${name}" tidak ditemukan! `));
    return false;
  }
  contact.forEach((contact, i) => {
    console.log(chalk.grey.inverse.bold(`${i + 1}. Nama :${contact.name} `));
    console.log(`   Email :${contact.email}`);
  });
};
// detail berdasarkan email
const detailContact = (email) => {
  const contacts = loadcont();
  const contact = contacts.find((contact) => contact.email === email);
  if (!contact) {
    console.log(chalk.red.inverse.bold(`"${email}" tidak ditemukan! `));
    return false;
  }

  console.log(chalk.grey.inverse.bold(` Email :${contact.email} `));
  console.log(` Nama :${contact.name}`);

  if (contact.no) {
    console.log(` No Hp :${contact.no}`);
  }
  if (contact.desc) {
    console.log(` Description :${contact.desc}`);
  }
};
// update contact
const updateContact = (email, newName, newEmail, newDesc, newNo) => {
  const contacts = loadcont();
  const contact = contacts.find((contact) => contact.email === email);

  if (!contact) {
    console.log(chalk.red.inverse.bold(`"${email}" tidak ditemukan! `));
    return false;
  }

  if (newName) {
    contact.name = newName;
  }
  if (newEmail) {
    contact.email = newEmail;
    if (!validator.isEmail(contact.email)) {
      console.log(chalk.red.inverse.bold(`Email: "${email}", tidak valid!`));
      return false;
    }
  }
  if (newDesc) {
    contact.desc = newDesc;
  }
  if (newNo) {
    contact.no = newNo;
    if (!validator.isMobilePhone(contact.no, "id-ID")) {
      console.log(
        chalk.red.inverse.bold(`Nomor: "${contact.no}", tidak valid!`)
      );
      return false;
    }
  }

  fs.writeFileSync("data/contact.json", JSON.stringify(contacts));
  console.log(
    chalk.green.inverse.bold(`Contact "${contact.name}" berhasil di Update!`)
  );
};
// hapus contact
const deleteContact = (email) => {
  const contacts = loadcont();
  const newCont = contacts.filter((contact) => contact.email !== email);

  if (contacts.length === newCont.length) {
    console.log(chalk.red.inverse.bold(`"${email}" tidak ditemukan! `));
    return false;
  }

  fs.writeFileSync("data/contact.json", JSON.stringify(newCont));
  console.log(chalk.green.inverse.bold(`Contact berhasil dihapus!`));
};

module.exports = {
  addContact,
  listContact,
  searchContact,
  detailContact,
  updateContact,
  deleteContact,
};
